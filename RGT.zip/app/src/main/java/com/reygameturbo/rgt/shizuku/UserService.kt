package com.reygameturbo.rgt.shizuku

import android.content.Context
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

@Keep
class UserService : IUserService.Stub() {
    constructor()
    @Keep constructor(@Suppress("UNUSED_PARAMETER") context: Context) : this()

    override fun destroy() {
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    override fun execute(action: String?): String {
        if (action == null) return "ERROR: missing action"
        val command = when (action) {
            "turbo_on" -> listOf("settings", "put", "global", "window_animation_scale", "0.5") to listOf(
                listOf("settings", "put", "global", "transition_animation_scale", "0.5"),
                listOf("settings", "put", "global", "animator_duration_scale", "0.5")
            )
            "turbo_off" -> listOf("settings", "put", "global", "window_animation_scale", "1.0") to listOf(
                listOf("settings", "put", "global", "transition_animation_scale", "1.0"),
                listOf("settings", "put", "global", "animator_duration_scale", "1.0")
            )
            "refresh_60" -> listOf("settings", "put", "system", "peak_refresh_rate", "60.0") to emptyList()
            "refresh_90" -> listOf("settings", "put", "system", "peak_refresh_rate", "90.0") to emptyList()
            "refresh_120" -> listOf("settings", "put", "system", "peak_refresh_rate", "120.0") to emptyList()
            "refresh_144" -> listOf("settings", "put", "system", "peak_refresh_rate", "144.0") to emptyList()
            else -> return "ERROR: unsupported action"
        }
        return try {
            val results = mutableListOf<String>()
            val commands = listOf(command.first) + command.second
            for (cmd in commands) {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
                val output = BufferedReader(InputStreamReader(p.inputStream)).use { it.readText().trim() }
                val code = p.waitFor()
                results += "exit=$code ${if (output.isBlank()) "ok" else output.take(160)}"
            }
            results.joinToString(" | ")
        } catch (e: Exception) {
            "ERROR: ${e.javaClass.simpleName}: ${e.message ?: "unknown"}"
        }
    }
}
